"""smaxpack.py -- preference-family dispatch: S-max assignment + fast raster decoder.

Family finding (prob_32, verified): the Z3-optimal assignment (every block to its most-preferred bay,
Z3=0) admits Z1_relax = 0 PROVEN OPTIMAL in every bay via the cumulative area relaxation, while the
engine's own assignment pays w3*3143 to hold Z1 at 1244 -- package LB 29k vs engine 6.04M. On
preference-heavy spacious instances the assignment logic, not packing, is the binding error.

Dispatch = gate + seed:
  gate:   S-max assignment; per-bay CP-SAT cumulative (area x time) tardiness relaxation with a short
          time limit; proceed only if every bay PROVES optimal 0 (spacious certificate).
  decode: per-bay event-driven EDD earliest-fit on a 1x1 occupancy grid (conservative cell rasteriza-
          tion of real footprints -> disjoint cells imply interior-disjoint polygons, so every checker
          stage passes by construction). Orientations tried in ascending mask-area order.
Adoption is ALWAYS by whole-solution utils.check_feasibility best-of in the caller. Never regresses.
"""
import math
import time

import numpy as np
from shapely.geometry import Polygon, box
from shapely.ops import unary_union
from shapely.prepared import prep


# ----------------------------------------------------------------------------------------------
def smax_assignment(prob):
    B = prob["blocks"]; m = len(prob["bays"])
    return {i: max(range(m), key=lambda j: B[i]["bay_preferences"][j]) for i in range(len(B))}


def fit_fix_assignment(prob, assign, cache, deadline=None):
    """Reassign any block that cannot fit its assigned bay (integer placements, any orientation) to
    the highest-preference bay where it does fit. Returns fixed assign or None if some block fits
    nowhere. Mask containment is exact for integer positions, so this is a true feasibility fix."""
    B = prob["blocks"]; bays = prob["bays"]
    dims = [(int(b["width"]), int(b["height"])) for b in bays]

    def fits(i, j):
        W, H = dims[j]
        for oi in range(len(B[i]["shape"])):
            M, _, _ = _mask(B[i], oi, cache)
            if M.shape[0] <= H and M.shape[1] <= W:
                return True
        return False

    out = dict(assign)
    for _ci, i in enumerate(out):
        if deadline is not None and (_ci & 15) == 0 and time.time() > deadline:
            return None
        if fits(i, out[i]):
            continue
        alts = [j for j in range(len(bays)) if fits(i, j)]
        if not alts:
            return None
        out[i] = max(alts, key=lambda j: B[i]["bay_preferences"][j])
    return out


def relax_lb(prob, assign, tl_per_bay=4.0, detail=False, deadline=None):
    """Per-bay cumulative(area) tardiness relaxation.
    Returns (sum of proven bounds, sum of feasible objectives, all bays proven zero)
    or, with detail=True, additionally a per-bay list of
    {bay, ids, obj, bound, tardy:{block: relax_tardiness}} for assignment repair."""
    from ortools.sat.python import cp_model
    B = prob["blocks"]; bays = prob["bays"]
    total_bd = 0.0; total_obj = 0.0; all_zero = True
    det = []
    for j in range(len(bays)):
        ids = [i for i in assign if assign[i] == j]
        if not ids:
            continue
        if deadline is not None and time.time() > deadline - tl_per_bay:
            total_obj = float("inf"); all_zero = False
            if detail:
                det.append({"bay": j, "ids": list(ids), "obj": float("inf"), "bound": 0.0,
                            "tardy": {}})
            continue
        cap = int(bays[j]["width"] * bays[j]["height"])
        HZ = max(int(B[i]["due_date"]) for i in ids) + 300
        ms = cp_model.CpModel(); ivs = []; dem = []; tds = []
        for i in ids:
            R = int(math.ceil(B[i]["release_time"] - 1e-9))
            P = max(1, int(math.ceil(B[i]["processing_time"] - 1e-9)))
            D = int(round(B[i]["due_date"]))
            e = ms.NewIntVar(R, HZ, "e%d" % i); f = ms.NewIntVar(R + P, HZ + P, "f%d" % i)
            ms.Add(f == e + P)
            ivs.append(ms.NewIntervalVar(e, P, f, "iv%d" % i))
            a = unary_union([Polygon(l).buffer(0) for l in B[i]["shape"][0]["layers"]]).area
            dem.append(int(math.ceil(a)))
            td = ms.NewIntVar(0, HZ, "t%d" % i); ms.Add(td >= f - D); tds.append(td)
        ms.AddCumulative(ivs, dem, cap)
        ms.Minimize(sum(tds))
        sv = cp_model.CpSolver()
        sv.parameters.max_time_in_seconds = tl_per_bay
        sv.parameters.num_search_workers = 4
        st = sv.Solve(ms)
        bd = sv.BestObjectiveBound()
        obj = sv.ObjectiveValue() if st in (cp_model.OPTIMAL, cp_model.FEASIBLE) else float("inf")
        total_bd += bd
        total_obj += obj
        if not (st == cp_model.OPTIMAL and obj <= 0.5):
            all_zero = False
        if detail:
            tard = {}
            if st in (cp_model.OPTIMAL, cp_model.FEASIBLE):
                for i, tv in zip(ids, tds):
                    v = sv.Value(tv)
                    if v > 0:
                        tard[i] = v
            det.append({"bay": j, "ids": list(ids), "obj": obj, "bound": bd, "tardy": tard})
    if detail:
        return total_bd, total_obj, all_zero, det
    return total_bd, total_obj, all_zero


# ----------------------------------------------------------------------------------------------
def _mask(bd, oi, cache):
    key = (id(bd), oi)
    if key in cache:
        return cache[key]
    fp = unary_union([Polygon(l).buffer(0) for l in bd["shape"][oi]["layers"]])
    b = fp.bounds
    lx0 = int(math.floor(b[0] + 1e-12)); ly0 = int(math.floor(b[1] + 1e-12))
    lx1 = int(math.ceil(b[2] - 1e-12)); ly1 = int(math.ceil(b[3] - 1e-12))
    mw = max(1, lx1 - lx0); mh = max(1, ly1 - ly0)
    pf = prep(fp)
    M = np.zeros((mh, mw), dtype=np.uint8)
    for cy in range(mh):
        for cx in range(mw):
            if pf.intersects(box(lx0 + cx, ly0 + cy, lx0 + cx + 1, ly0 + cy + 1)):
                M[cy, cx] = 1
    cache[key] = (M, lx0, ly0)
    return cache[key]


def repair_assignment(prob, assign, det, cache, deadline, max_moves=30, verbose=False):
    """Relieve relax-overloaded bays by moving blocks to slack bays at minimum preference loss.
    Movers must overlap the congested window ([min R, max D] over the bay's relax-tardy blocks) so a
    move actually relieves the violated cumulative constraint. Relief target per bay = sum over tardy
    blocks of area*relax_tardiness (the overflow area-time), moved load counted as area*P.
    Returns (new_assign, n_moves); n_moves == 0 means no useful move existed."""
    B = prob["blocks"]; bays = prob["bays"]; m = len(bays)
    dims = [(int(b["width"]), int(b["height"])) for b in bays]
    caps = [float(b["width"] * b["height"]) for b in bays]

    def fits(i, j):
        W, H = dims[j]
        for oi in range(len(B[i]["shape"])):
            M, _, _ = _mask(B[i], oi, cache)
            if M.shape[0] <= H and M.shape[1] <= W:
                return True
        return False

    _acache = {}

    def _area(i):
        if i not in _acache:
            _acache[i] = unary_union(
                [Polygon(l).buffer(0) for l in B[i]["shape"][0]["layers"]]).area
        return _acache[i]

    R = {i: int(math.ceil(B[i]["release_time"] - 1e-9)) for i in assign}
    P = {i: max(1, int(math.ceil(B[i]["processing_time"] - 1e-9))) for i in assign}
    D = {i: int(round(B[i]["due_date"])) for i in assign}
    load = {j: sum(_area(i) * P[i] for i in assign if assign[i] == j) for j in range(m)}
    over_bays = set(d["bay"] for d in det if d["obj"] > 0.5)
    newa = dict(assign); moves = 0
    for d in sorted([d for d in det if d["obj"] > 0.5], key=lambda d: -d["obj"]):
        if time.time() > deadline or moves >= max_moves:
            break
        j = d["bay"]; tard = d["tardy"]
        if not tard:
            continue
        w0 = min(R[i] for i in tard); w1 = max(D[i] for i in tard)
        need = 1.15 * sum(_area(i) * tard[i] for i in tard)
        cands = []
        for i in [x for x in newa if newa[x] == j]:
            if R[i] > w1 or D[i] < w0:                  # activity window misses congestion
                continue
            pref = B[i]["bay_preferences"]; smx = max(pref)
            alts = []
            for k in range(m):
                if k == j or k in over_bays or not fits(i, k):
                    continue
                if (load[k] + _area(i) * P[i]) / caps[k] < load[j] / caps[j]:
                    alts.append(k)
            if not alts:
                continue
            alt = max(alts, key=lambda k: pref[k])
            relief = _area(i) * P[i]
            cands.append(((smx - pref[alt]) / max(1.0, relief), smx - pref[alt], i, alt, relief))
        cands.sort()
        got = 0.0
        for _, ploss, i, alt, relief in cands:
            if got >= need or moves >= max_moves:
                break
            newa[i] = alt
            load[alt] += relief; load[j] -= relief
            got += relief; moves += 1
            if verbose:
                print("    repair: block %d bay%d->bay%d (ploss=%d, relief=%.0f)"
                      % (i, j, alt, ploss, relief), flush=True)
    return newa, moves


def _perim(M):
    """4-neighborhood ring around the footprint mask (within a +1 padded frame)."""
    mh, mw = M.shape
    Mp = np.zeros((mh + 2, mw + 2), dtype=np.uint8); Mp[1:-1, 1:-1] = M
    dil = Mp.copy()
    dil[1:, :] |= Mp[:-1, :]; dil[:-1, :] |= Mp[1:, :]
    dil[:, 1:] |= Mp[:, :-1]; dil[:, :-1] |= Mp[:, 1:]
    return (dil & (1 - Mp)).astype(np.uint8)


def decode(prob, assign, deadline_ts, verbose=False, cache=None, okey=None, return_recs=False,
           place="bl"):
    """Event-driven earliest-fit per bay on an occupancy count grid. okey selects the waiting order:
    None/'edd' -> (due, -P); 'bigfirst' -> (due, -mask_area). place selects the position rule:
    'bl' first free bottom-left; 'contact' the free position with maximum contact to walls and
    already-placed blocks (preserves contiguous free space for the oversized blocks that dominate
    family-instance tardiness). Returns sol dict, or the raw recs {block: (bay,x,y,oi,entry,exit)}
    when return_recs=True; None on failure/deadline."""
    B = prob["blocks"]; bays = prob["bays"]
    cache = {} if cache is None else cache
    recs = {}
    for j in range(len(bays)):
        ids = [i for i in assign if assign[i] == j]
        if not ids:
            continue
        W, H = int(bays[j]["width"]), int(bays[j]["height"])
        O = np.zeros((H, W), dtype=np.int16)
        R = {i: int(math.ceil(B[i]["release_time"] - 1e-9)) for i in ids}
        P = {i: max(1, int(math.ceil(B[i]["processing_time"] - 1e-9))) for i in ids}
        orients = {i: list(range(len(B[i]["shape"]))) for i in ids}
        for i in ids:                                   # ascending mask area
            orients[i].sort(key=lambda oi: int(_mask(B[i], oi, cache)[0].sum()))
        if okey == "bigfirst":
            waiting = sorted(ids, key=lambda i: (B[i]["due_date"],
                                                 -int(_mask(B[i], orients[i][0], cache)[0].sum())))
        else:
            waiting = sorted(ids, key=lambda i: (B[i]["due_date"], -P[i]))
        events = sorted(set(R[i] for i in ids))
        active = []                                     # (exit_t, mask, gy, gx)
        t = events[0]
        guard = 0
        while waiting:
            if time.time() > deadline_ts:
                return None
            guard += 1
            if guard > 20000:
                return None
            for k in range(len(active) - 1, -1, -1):
                if active[k][0] <= t:
                    ex, M, gy, gx = active.pop(k)
                    O[gy:gy + M.shape[0], gx:gx + M.shape[1]] -= M
            scanned = 0
            for i in list(waiting):
                if R[i] > t:
                    continue
                scanned += 1
                if scanned > 400:
                    break
                free_cells = int(O.size - np.count_nonzero(O))
                got = None
                Opad = None
                if place == "contact":
                    Opad = np.ones((H + 2, W + 2), dtype=np.uint8)
                    Opad[1:-1, 1:-1] = (O > 0).astype(np.uint8)
                for oi in orients[i]:
                    M, lx0, ly0 = _mask(B[i], oi, cache)
                    mh, mw = M.shape
                    if mh > H or mw > W or int(M.sum()) > free_cells:
                        continue
                    SW = np.lib.stride_tricks.sliding_window_view(O, (mh, mw))
                    coll = np.tensordot(SW, M, axes=([2, 3], [0, 1]))
                    free = np.argwhere(coll == 0)
                    if free.size:
                        if place == "contact":
                            pk = (id(B[i]), oi, "pm")
                            if pk not in cache:
                                cache[pk] = _perim(M)
                            SWp = np.lib.stride_tricks.sliding_window_view(Opad,
                                                                           (mh + 2, mw + 2))
                            sc = np.tensordot(SWp, cache[pk], axes=([2, 3], [0, 1]))
                            v = sc[free[:, 0], free[:, 1]]
                            k = np.lexsort((free[:, 1], free[:, 0], -v))[0]
                            gy, gx = free[k]
                        else:
                            gy, gx = free[0]
                        got = (oi, M, int(gy), int(gx), lx0, ly0)
                        break
                if got is None:
                    continue
                oi, M, gy, gx, lx0, ly0 = got
                O[gy:gy + M.shape[0], gx:gx + M.shape[1]] += M
                e = t; f = t + P[i]
                active.append((f, M, gy, gx))
                recs[i] = (j, gx - lx0, gy - ly0, oi, e, f)
                waiting.remove(i)
                events.append(f)
            events = sorted(set(ev for ev in events if ev > t))
            if not waiting:
                break
            if not events:
                t += 1
            else:
                t = events[0]
        if verbose:
            print("  smaxpack bay%d: placed %d/%d" % (j, sum(1 for i in ids if i in recs), len(ids)),
                  flush=True)
        if any(i not in recs for i in ids):
            return None
    if return_recs:
        return recs
    return _recs_to_sol(recs)


def _recs_to_sol(recs):
    ent_at = {}; ext_at = {}
    for i, v in recs.items():
        ext_at.setdefault(int(v[5]), []).append(i)
        ent_at.setdefault(int(v[4]), []).append(i)
    ops = {}
    for tt in sorted(set(ent_at) | set(ext_at)):        # ascending time; EXITs before ENTRYs per key
        L = []
        for i in ext_at.get(tt, []):
            L.append({"type": "EXIT", "block_id": i, "bay_id": recs[i][0]})
        for i in ent_at.get(tt, []):
            v = recs[i]
            L.append({"type": "ENTRY", "block_id": i, "bay_id": v[0], "x": int(v[1]),
                      "y": int(v[2]), "orient_idx": int(v[3])})
        ops[str(tt)] = L
    return {"operations": ops}


# ----------------------------------------------------------------------------------------------
def optimize(prob, assign, cache, deadline, verbose=False):
    """Decode-verified improvement rounds on top of a gated assignment.
    Round 0 races order keys (EDD vs big-first). Each later round proposes economic moves out of the
    tardiest bay -- blocks whose w1*tardiness*0.7 exceeds w3*preference_loss, plus one speculative
    largest movable block (indirect relief for stuck oversized blocks) -- then re-decodes; the full
    package objective w1*Z1 + w2*ceil(Z2) + w3*Z3 is compared and only improvements are kept, so the
    result can never be worse than the plain gated decode."""
    B = prob["blocks"]; bays = prob["bays"]; m = len(bays)
    w = prob.get("weights", {"w1": 1, "w2": 0, "w3": 0})
    P = {i: max(1, int(math.ceil(B[i]["processing_time"] - 1e-9))) for i in assign}
    D = {i: int(round(B[i]["due_date"])) for i in assign}
    uw = [sum(b["width"] * b["height"] for b in bays) / m /
          (bays[j]["width"] * bays[j]["height"]) for j in range(m)]

    def z23(a):
        loads = [0.0] * m; z3 = 0
        for i, j in a.items():
            loads[j] += B[i]["workload"]
            pr = B[i]["bay_preferences"]; z3 += max(pr) - pr[j]
        z2 = 0.0
        for x in range(m):
            for y in range(x + 1, m):
                z2 = max(z2, abs(uw[x] * loads[x] - uw[y] * loads[y]))
        return w["w2"] * math.ceil(z2) + w["w3"] * z3

    def fits(i, j):
        W, H = int(bays[j]["width"]), int(bays[j]["height"])
        for oi in range(len(B[i]["shape"])):
            M, _, _ = _mask(B[i], oi, cache)
            if M.shape[0] <= H and M.shape[1] <= W:
                return True
        return False

    _ac = {}

    def _A(i):
        if i not in _ac:
            _ac[i] = float(_mask(B[i], 0, cache)[0].sum())
        return _ac[i]

    def ev(a, ok, pl):
        recs = decode(prob, a, deadline, cache=cache, okey=ok, return_recs=True, place=pl)
        if recs is None:
            return None, None
        z1 = sum(max(0, v[5] - D[i]) for i, v in recs.items())
        return w["w1"] * z1 + z23(a), recs

    def propose(recs, a0):
        """One round of economic moves derived from a decoded state. Returns new assign or None."""
        a = dict(a0)
        btd = [0] * m
        for i, v in recs.items():
            btd[v[0]] += max(0, v[5] - D[i])
        j = max(range(m), key=lambda k: btd[k])
        if btd[j] <= 0:
            return None
        loadr = [sum(_A(i) * P[i] for i in a if a[i] == k) /
                 float(bays[k]["width"] * bays[k]["height"]) for k in range(m)]
        cand = []
        for i in [x for x in a if a[x] == j]:
            pr = B[i]["bay_preferences"]; smx = max(pr)
            alts = [k for k in range(m) if k != j and fits(i, k) and loadr[k] < loadr[j]]
            if not alts:
                continue
            k = max(alts, key=lambda q: pr[q])
            tard = max(0, recs[i][5] - D[i])
            cand.append((w["w1"] * tard * 0.7 - w["w3"] * (smx - pr[k]), _A(i) * P[i], i, k))
        cand.sort(key=lambda t: (-t[0], -t[1]))
        moved = 0
        for gain, big, i, k in cand:
            if gain <= 0 or moved >= 6:
                break
            a[i] = k; moved += 1
        if moved == 0 and cand:                          # speculative: largest movable, bounded ploss
            gain, big, i, k = max(cand, key=lambda t: t[1])
            pr = B[i]["bay_preferences"]
            if max(pr) - pr[k] <= 60:
                a[i] = k; moved = 1
        return a if moved else None

    best = [None, None, None]                            # GLOBAL best across both trajectories
    alt_combos = (("edd", "contact"), ("bigfirst", "contact"))
    alt_seen = []                                        # (obj, combo) from stream-A round-0 side evals

    def run_traj(steer, rounds, dl):
        """steer=None -> the validated smax3 stream (edd every round + bigfirst at round 0, moves from
        its own best). steer=(okey,place) -> a secondary stream fully steered by that combo."""
        cur = dict(assign)
        tb = (None, None, None)
        for rd in range(rounds):
            keys = [steer] if steer else ([("edd", "bl")] if rd else [("edd", "bl"),
                                                                      ("bigfirst", "bl")])
            for ok, pl in keys:
                if time.time() > dl - 3.0:
                    return
                obj, recs = ev(cur, ok, pl)
                if obj is not None and (tb[0] is None or obj < tb[0] - 1e-9):
                    tb = (obj, dict(cur), recs)
                if obj is not None and (best[0] is None or obj < best[0] - 1e-9):
                    best[0], best[1], best[2] = obj, dict(cur), recs
                    if verbose:
                        print("  smaxpack opt %s r%d/%s-%s: obj=%.0f"
                              % ("B" if steer else "A", rd, ok, pl, obj), flush=True)
            if steer is None and rd == 0:                # contact side candidates ride along stream A
                for ok, pl in alt_combos:
                    if time.time() > dl - 3.0:
                        break
                    obj2, recs2 = ev(cur, ok, pl)
                    if obj2 is not None:
                        alt_seen.append((obj2, (ok, pl)))
                        if best[0] is None or obj2 < best[0] - 1e-9:
                            best[0], best[1], best[2] = obj2, dict(cur), recs2
                            if verbose:
                                print("  smaxpack opt A r0/%s-%s: obj=%.0f" % (ok, pl, obj2),
                                      flush=True)
            if tb[0] is None or time.time() > dl - 6.0:
                return
            na = propose(tb[2], tb[1])
            if na is None:
                return
            cur = na

    run_traj(None, 4, deadline)                          # stream A: the validated trajectory
    if alt_seen and time.time() < deadline - 10.0:       # stream B: steered by the best contact combo
        run_traj(min(alt_seen)[1], 3, deadline)
    if best[0] is None:
        return None
    return _recs_to_sol(best[2])


def _fluid_reject(prob, smax):
    """Millisecond congestion proxy on the raw S-max assignment (bbox areas, blocks start at
    release). Calibrated on all 40 training instances: family PASSes have overflow_days <= 790 and
    peak <= 3.78; the pathological congested group starts at 1239 / 4.03. Rejecting at ovd > 850 or
    peak > 4.5 kills hopeless instances before ANY shapely/CP work."""
    B = prob["blocks"]; bays = prob["bays"]; m = len(bays)
    for j in range(m):
        ids = [i for i in smax if smax[i] == j]
        if not ids:
            continue
        cap = float(bays[j]["width"] * bays[j]["height"])
        ev = []; sA = 0.0
        for i in ids:
            vs = [v for l in B[i]["shape"][0]["layers"] for v in l]
            bA = ((max(v[0] for v in vs) - min(v[0] for v in vs)) *
                  (max(v[1] for v in vs) - min(v[1] for v in vs)))
            sA += bA
            R = math.ceil(B[i]["release_time"] - 1e-9)
            P = max(1, math.ceil(B[i]["processing_time"] - 1e-9))
            ev.append((R, bA)); ev.append((R + P, -bA))
        ev.sort()
        used = 0.0; last = None; ov = 0.0; pk = 0.0
        for t, d in ev:
            if last is not None and t > last and used > cap:
                ov += (used - cap) * (t - last)
            used += d; pk = max(pk, used / cap); last = t
        if pk > 4.5 or ov / max(1.0, sA / len(ids)) > 850.0:
            return True
    return False


def smax_dispatch(prob, utils, time_budget=45.0, verbose=False):
    """Gate + decode. Returns a feasible candidate sol or None. Caller does best-of."""
    t0 = time.time()
    hard_ts = t0 + max(6.0, float(time_budget))         # ABSOLUTE budget wall for the whole dispatch
    try:
        cache = {}
        assign = smax_assignment(prob)
        if _fluid_reject(prob, assign):                 # milliseconds; kills hopeless instances
            return None
        assign = fit_fix_assignment(prob, assign, cache, deadline=hard_ts - 2.0)
        if assign is None:
            return None
        n = len(prob["blocks"]); m = len(prob["bays"])
        lb, lobj, all_zero, det = relax_lb(prob, assign,
                                           tl_per_bay=min(6.0, max(2.5, time_budget / (4 * m))),
                                           detail=True, deadline=hard_ts - 2.0)
        tpb = min(6.0, max(2.5, time_budget / (4 * m)))
        if verbose:
            print("  smaxpack gate: relax LB=%.0f obj=%.0f (%.0fs)"
                  % (lb, lobj, time.time() - t0), flush=True)
        if lobj > 150.0:
            rem = time_budget - (time.time() - t0)
            if not (lobj <= 3000.0 and rem >= 12.0):
                return None
            for _round in range(2):
                assign2, mv = repair_assignment(prob, assign, det, cache,
                                                deadline=hard_ts - 8.0, verbose=verbose)
                if not mv:
                    return None
                assign = assign2
                lb, lobj, all_zero, det = relax_lb(prob, assign, tl_per_bay=min(tpb, 3.0),
                                                   detail=True)
                if verbose:
                    print("  smaxpack repair r%d: moved=%d relax obj=%.0f (%.0fs)"
                          % (_round + 1, mv, lobj, time.time() - t0), flush=True)
                if lobj <= 150.0 or time.time() - t0 > time_budget - 12.0:
                    break
            if lobj > 150.0:
                return None
        sol = optimize(prob, assign, cache,
                       deadline=min(hard_ts - 1.5, time.time() + 48.0), verbose=verbose)
        if sol is None:
            return None
        r = utils.check_feasibility(prob, sol)
        if verbose:
            print("  smaxpack: feasible=%s obj=%s Z1=%s Z2=%s Z3=%s (%.0fs)"
                  % (r.get("feasible"), r.get("objective"), r.get("obj1"), r.get("obj2"),
                     r.get("obj3"), time.time() - t0), flush=True)
        return sol if r.get("feasible") else None
    except Exception as _e:
        if verbose:
            print("  smaxpack EXC: %r" % (_e,), flush=True)
        return None


if __name__ == "__main__":
    import json, sys
    sys.path.insert(0, ".")
    import utils
    pth = sys.argv[1] if len(sys.argv) > 1 else "../allinst/prob_32.json"
    prob = json.load(open(pth))
    t = time.time()
    sol = smax_dispatch(prob, utils, time_budget=float(sys.argv[2]) if len(sys.argv) > 2 else 60.0,
                        verbose=True)
    if sol is None:
        print("dispatch: None")
    else:
        r = utils.check_feasibility(prob, sol)
        print("RESULT (%.0fs): feasible=%s obj=%.0f Z1=%.0f Z2=%.1f Z3=%.0f"
              % (time.time() - t, r["feasible"], r["objective"], r["obj1"], r["obj2"], r["obj3"]))
