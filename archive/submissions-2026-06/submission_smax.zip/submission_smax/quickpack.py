"""myalgorithm.py -- OGC 2026 clean single-abstraction solver.

ONE representation, ONE decoder, ONE objective.

    A *solution* is a pair (assign, order) where
        assign[i] = bay that block i is placed in,
        order[j]  = the list of blocks in bay j, in the priority sequence
                    that the decoder will pack them.

    The DECODER packs each bay's blocks, in priority order, footprint-disjoint
    over time (axis-aligned bounding boxes never overlap while two blocks
    coexist in [entry, exit)).  Keystone fact: if footprint AABBs are pairwise
    disjoint whenever two blocks coexist in time, then no two layers at the same
    level can overlap and the crane can always lift vertically -> BOTH the
    collision constraint AND the crane constraint hold for *any* operation
    order.  Hence every decoded solution is feasible by construction.

    The objective is then closed-form:
        Z2 (workload imbalance) and Z3 (preference) depend only on `assign`;
        Z1 (tardiness) is read straight off the packed exit times.

Why this fixes the P3 regression and aims higher:
  * The construct step already DECODES to a real time-shared parallel pack, so
    the worst case we ever return is a good parallel packing -- never the
    single-occupancy floor that the previous engine collapsed to on the large
    bay / short budget instance.
  * No fragile size/density gates route a large bay into a cell-rasterising
    CP-SAT packer.  CP-SAT is used ONLY for the pure assignment sub-problem
    (Z2+Z3), which is small and exactly where it helps; packing is always the
    same linear-time geometric decoder.
  * Search (per-bay reordering for Z1 + cross-bay SA reassignment trading
    Z1/Z2/Z3) operates on the single representation and is strictly anytime:
    it always keeps and returns the best decoded solution seen so far.

Self-contained: depends only on the standard library, and (optionally) ortools
for the assignment seed.  utils.py is used only for the final feasibility
check.
"""

import math
import time
import random
import os
import ctypes

try:
    import numpy as _np
    _HAVE_NP = True
except Exception:
    _np = None
    _HAVE_NP = False


# ===========================================================================
# Fast C decoder (optional).  Identical semantics to the pure-Python reference
# below; used only to accelerate the same single decoder.  Layered loading:
# shipped .so -> compile shipped/embedded .c -> pure Python.
# ===========================================================================

_C_SOURCE = r'''
#include <stdlib.h>
#include <math.h>
#define EPS 1e-9
static int ceil_i(double v){ return (int)ceil(v - 1e-12); }
static int cmp_int(const void *a,const void *b){
    int x=*(const int*)a,y=*(const int*)b; return (x>y)-(x<y);
}
static int best_fit(double W,double H,double lx0,double ly0,double w,double h,
                    int np,const double*pX0,const double*pY0,const double*pX1,const double*pY1,
                    int*xs_buf,int*ys_buf,
                    int*opx,int*opy,double*oX0,double*oY0,double*oX1,double*oY1){
    int base_x=ceil_i(-lx0); if(base_x<0)base_x=0;
    int base_y=ceil_i(-ly0); if(base_y<0)base_y=0;
    int nxc=0,nyc=0; xs_buf[nxc++]=base_x; ys_buf[nyc++]=base_y;
    for(int k=0;k<np;++k){
        int nx=ceil_i(pX1[k]-lx0);
        if(nx>=0 && nx+lx0+w<=W+EPS) xs_buf[nxc++]=nx;
        int ny=ceil_i(pY1[k]-ly0);
        if(ny>=0 && ny+ly0+h<=H+EPS) ys_buf[nyc++]=ny;
    }
    qsort(xs_buf,nxc,sizeof(int),cmp_int);
    qsort(ys_buf,nyc,sizeof(int),cmp_int);
    int nxs=0;
    for(int i=0;i<nxc;++i){
        if(i>0 && xs_buf[i]==xs_buf[i-1]) continue;
        double X0=xs_buf[i]+lx0; if(X0>=-EPS && X0+w<=W+EPS) xs_buf[nxs++]=xs_buf[i];
    }
    int nys=0;
    for(int i=0;i<nyc;++i){
        if(i>0 && ys_buf[i]==ys_buf[i-1]) continue;
        double Y0=ys_buf[i]+ly0; if(Y0>=-EPS && Y0+h<=H+EPS) ys_buf[nys++]=ys_buf[i];
    }
    for(int iy=0;iy<nys;++iy){
        double Y0=ys_buf[iy]+ly0,Y1=Y0+h;
        for(int ix=0;ix<nxs;++ix){
            double X0=xs_buf[ix]+lx0,X1=X0+w; int ok=1;
            for(int k=0;k<np;++k){
                if(X0<pX1[k]-EPS && pX0[k]<X1-EPS && Y0<pY1[k]-EPS && pY0[k]<Y1-EPS){ok=0;break;}
            }
            if(ok){*opx=xs_buf[ix];*opy=ys_buf[iy];*oX0=X0;*oY0=Y0;*oX1=X1;*oY1=Y1;return 1;}
        }
    }
    return 0;
}
int decode_bay(double W,double H,int nblk,
               const int*rel,const int*proc,
               const int*ostart,const int*oend,
               const int*goidx,const double*golx,const double*goly,
               const double*gow,const double*goh,
               int ent_cap,
               int*out_x,int*out_y,int*out_oi,long*out_entry,long*out_exit){
    if(nblk<=0) return 0;
    double*aX0=malloc(sizeof(double)*nblk),*aY0=malloc(sizeof(double)*nblk);
    double*aX1=malloc(sizeof(double)*nblk),*aY1=malloc(sizeof(double)*nblk);
    long*aE=malloc(sizeof(long)*nblk),*aF=malloc(sizeof(long)*nblk);
    double*pX0=malloc(sizeof(double)*(nblk+1)),*pY0=malloc(sizeof(double)*(nblk+1));
    double*pX1=malloc(sizeof(double)*(nblk+1)),*pY1=malloc(sizeof(double)*(nblk+1));
    int*cand_t=malloc(sizeof(int)*(nblk+1));
    int*xs_buf=malloc(sizeof(int)*(nblk+2)),*ys_buf=malloc(sizeof(int)*(nblk+2));
    if(!aX0||!aY0||!aX1||!aY1||!aE||!aF||!pX0||!pY0||!pX1||!pY1||!cand_t||!xs_buf||!ys_buf){
        free(aX0);free(aY0);free(aX1);free(aY1);free(aE);free(aF);
        free(pX0);free(pY0);free(pX1);free(pY1);free(cand_t);free(xs_buf);free(ys_buf);
        return -1;
    }
    int nact=0;
    for(int b=0;b<nblk;++b){
        int r=rel[b],p=proc[b];
        int nc=0; cand_t[nc++]=r;
        for(int a=0;a<nact;++a) if(aF[a]>r) cand_t[nc++]=(int)aF[a];
        qsort(cand_t,nc,sizeof(int),cmp_int);
        int uc=0;
        for(int i=0;i<nc;++i){ if(i>0&&cand_t[i]==cand_t[i-1])continue; cand_t[uc++]=cand_t[i]; }
        if(uc>ent_cap) uc=ent_cap;
        int found=0; long best_e=0; int best_x=0,best_y=0,best_oi=0;
        double best_Y1=0,bX0=0,bY0=0,bX1=0,bY1=0;
        for(int ci=0;ci<uc;++ci){
            int e=cand_t[ci];
            int np=0;
            for(int a=0;a<nact;++a) if(aF[a]>e && aE[a]<e+p){
                pX0[np]=aX0[a];pY0[np]=aY0[a];pX1[np]=aX1[a];pY1[np]=aY1[a];np++;
            }
            int e_has=0; double e_bY1=0; int e_x=0,e_y=0,e_oi=0;
            double eX0=0,eY0=0,eX1=0,eY1=0;
            for(int oo=ostart[b];oo<oend[b];++oo){
                int px,py; double X0,Y0,X1,Y1;
                if(best_fit(W,H,golx[oo],goly[oo],gow[oo],goh[oo],np,
                            pX0,pY0,pX1,pY1,xs_buf,ys_buf,&px,&py,&X0,&Y0,&X1,&Y1)){
                    if(!e_has || Y1<e_bY1){ e_has=1;e_bY1=Y1;e_x=px;e_y=py;e_oi=goidx[oo];
                        eX0=X0;eY0=Y0;eX1=X1;eY1=Y1; }
                }
            }
            if(e_has){
                if(!found || (long)e<best_e || ((long)e==best_e && e_bY1<best_Y1)){
                    found=1;best_e=e;best_Y1=e_bY1;best_x=e_x;best_y=e_y;best_oi=e_oi;
                    bX0=eX0;bY0=eY0;bX1=eX1;bY1=eY1;
                }
                break;
            }
        }
        if(!found){
            long e=r; for(int a=0;a<nact;++a) if(aF[a]>e) e=aF[a];
            int chosen=ostart[b],picked=0;
            for(int oo=ostart[b];oo<oend[b];++oo){
                double lx=golx[oo],ly=goly[oo],ww=gow[oo],hh=goh[oo];
                long pxl=(long)ceil(-lx-1e-9), pxh=(long)floor(W-ww-lx+1e-9);
                long pyl=(long)ceil(-ly-1e-9), pyh=(long)floor(H-hh-ly+1e-9);
                if(pxl<=pxh && pyl<=pyh){chosen=oo;picked=1;break;}
            }
            if(!picked) chosen=ostart[b];
            double lx0=golx[chosen],ly0=goly[chosen],w=gow[chosen],h=goh[chosen];
            int px=ceil_i(-lx0); if(px<0)px=0; int py=ceil_i(-ly0); if(py<0)py=0;
            best_e=e;best_x=px;best_y=py;best_oi=goidx[chosen];
            bX0=px+lx0;bY0=py+ly0;bX1=bX0+w;bY1=bY0+h;
        }
        long f=best_e+p;
        aX0[nact]=bX0;aY0[nact]=bY0;aX1[nact]=bX1;aY1[nact]=bY1;aE[nact]=best_e;aF[nact]=f;nact++;
        out_x[b]=best_x;out_y[b]=best_y;out_oi[b]=best_oi;out_entry[b]=best_e;out_exit[b]=f;
    }
    free(aX0);free(aY0);free(aX1);free(aY1);free(aE);free(aF);
    free(pX0);free(pY0);free(pX1);free(pY1);free(cand_t);free(xs_buf);free(ys_buf);
    return 0;
}
'''

_LIB = "uninit"


def _load_lib():
    """Return the loaded ctypes lib, or None. Cached."""
    global _LIB
    if _LIB != "uninit":
        return _LIB
    _LIB = None
    if not _HAVE_NP:
        return None
    try:
        here = os.path.dirname(os.path.abspath(__file__))
    except Exception:
        here = os.getcwd()
    candidates = []
    so_ship = os.path.join(here, "geomdecode.so")
    candidates.append(so_ship)
    # compile shipped .c next to module if no .so
    try:
        if not os.path.exists(so_ship):
            c_ship = os.path.join(here, "geomdecode.c")
            if not os.path.exists(c_ship):
                with open(c_ship, "w") as fh:
                    fh.write(_C_SOURCE)
            os.system("gcc -O3 -shared -fPIC -o '%s' '%s' 2>/dev/null" % (so_ship, c_ship))
    except Exception:
        pass
    # temp-dir compile of embedded source as last resort
    try:
        if not os.path.exists(so_ship):
            import tempfile
            d = tempfile.mkdtemp()
            c_tmp = os.path.join(d, "geomdecode.c")
            so_tmp = os.path.join(d, "geomdecode.so")
            with open(c_tmp, "w") as fh:
                fh.write(_C_SOURCE)
            os.system("gcc -O3 -shared -fPIC -o '%s' '%s' 2>/dev/null" % (so_tmp, c_tmp))
            candidates.append(so_tmp)
    except Exception:
        pass
    IP = ctypes.POINTER(ctypes.c_int)
    DP = ctypes.POINTER(ctypes.c_double)
    LP = ctypes.POINTER(ctypes.c_long)
    for so in candidates:
        if not os.path.exists(so):
            continue
        try:
            lib = ctypes.CDLL(so)
            lib.decode_bay.restype = ctypes.c_int
            lib.decode_bay.argtypes = [ctypes.c_double, ctypes.c_double, ctypes.c_int,
                IP, IP, IP, IP, IP, DP, DP, DP, DP, ctypes.c_int, IP, IP, IP, LP, LP]
            _LIB = lib
            return lib
        except Exception:
            continue
    return None


def _build_globals(P):
    """Flatten all blocks' orientations into static global arrays for the C path."""
    if not _HAVE_NP:
        return None
    n = P["n"]
    gostart = _np.zeros(n, _np.int32); goend = _np.zeros(n, _np.int32)
    goidx = []; golx = []; goly = []; gow = []; goh = []
    off = 0
    for i in range(n):
        gostart[i] = off
        for (oi, lx0, ly0, w, h) in P["orients"][i]:
            goidx.append(oi); golx.append(lx0); goly.append(ly0)
            gow.append(w); goh.append(h); off += 1
        goend[i] = off
    return {
        "gostart": gostart, "goend": goend,
        "goidx": _np.ascontiguousarray(goidx, _np.int32),
        "golx": _np.ascontiguousarray(golx, _np.float64),
        "goly": _np.ascontiguousarray(goly, _np.float64),
        "gow": _np.ascontiguousarray(gow, _np.float64),
        "goh": _np.ascontiguousarray(goh, _np.float64),
        "grel": _np.ascontiguousarray(P["rel"], _np.int32),
        "gproc": _np.ascontiguousarray(P["proc"], _np.int32),
    }


# ===========================================================================
# Preprocessing
# ===========================================================================

def _ori_fits_bay(lx0, ly0, w, h, W, H, eps=1e-9):
    """True iff some INTEGER reference (px,py) places the footprint fully inside
    [0,W]x[0,H].  Because the validator rounds x,y to integers, ceil(h)<=H is
    NOT sufficient: the fractional reference offset (lx0,ly0 <= 0) can make a
    block that is numerically shorter than the bay still impossible to seat."""
    return (math.ceil(-lx0 - eps) <= math.floor(W - w - lx0 + eps) and
            math.ceil(-ly0 - eps) <= math.floor(H - h - ly0 + eps))

def _prep(prob):
    bays = prob["bays"]
    m = len(bays)
    BW = [int(b["width"]) for b in bays]
    BH = [int(b["height"]) for b in bays]
    areas = [BW[j] * BH[j] for j in range(m)]
    avg_area = sum(areas) / m if m else 1.0
    u = [avg_area / areas[j] if areas[j] else 0.0 for j in range(m)]

    blocks = prob["blocks"]
    n = len(blocks)
    rel = [0] * n; proc = [0] * n; due = [0] * n; wl = [0] * n
    pref = [None] * n; smax = [0] * n
    orients = [None] * n          # orients[i] = [(orient_idx, lx0, ly0, w, h), ...] sorted by area
    fitbays = [None] * n

    for i, b in enumerate(blocks):
        rel[i] = int(b["release_time"]); proc[i] = int(b["processing_time"])
        due[i] = int(b["due_date"]); wl[i] = int(b.get("workload", 0))
        p = list(b["bay_preferences"]); pref[i] = p; smax[i] = max(p) if p else 0
        seen = {}
        for oi, o in enumerate(b["shape"]):
            try:
                # match utils._resolve_layers: drop empty layers, then the
                # reference point is the FIRST vertex of the first non-empty
                # layer (the validator translates every layer by x-ref,y-ref).
                layers = [list(L) for L in o["layers"] if L]
                if layers and layers[0]:
                    refx, refy = layers[0][0][0], layers[0][0][1]
                else:
                    refx, refy = 0.0, 0.0
                xs = [v[0] - refx for L in layers for v in L]
                ys = [v[1] - refy for L in layers for v in L]
                if not xs or not ys:
                    continue
                lx0 = min(xs); ly0 = min(ys)
                w = max(xs) - lx0; h = max(ys) - ly0
                key = (round(lx0, 3), round(ly0, 3), round(w, 3), round(h, 3))
                if key not in seen:
                    seen[key] = (oi, lx0, ly0, w, h)
            except Exception:
                continue
        ol = list(seen.values())
        if not ol:
            ol = [(0, 0.0, 0.0, 1.0, 1.0)]
        ol.sort(key=lambda t: t[3] * t[4])
        orients[i] = ol
        fb = []
        for j in range(m):
            for (oi, lx0, ly0, w, h) in ol:
                if _ori_fits_bay(lx0, ly0, w, h, BW[j], BH[j]):
                    fb.append(j); break
        if not fb:
            fb = list(range(m))
        fitbays[i] = fb

    P = {
        "m": m, "n": n, "BW": BW, "BH": BH, "areas": areas, "u": u,
        "rel": rel, "proc": proc, "due": due, "wl": wl, "pref": pref, "smax": smax,
        "orients": orients, "fitbays": fitbays,
        "w1": float(prob.get("weights", {}).get("w1", 1.0)),
        "w2": float(prob.get("weights", {}).get("w2", 1.0)),
        "w3": float(prob.get("weights", {}).get("w3", 1.0)),
    }
    P["_lib"] = _load_lib()
    P["_G"] = _build_globals(P) if P["_lib"] is not None else None
    if P["_G"] is None:
        P["_lib"] = None
    return P


# ===========================================================================
# Decoder: per-bay footprint-disjoint packing over time
# ===========================================================================

def _best_fit(W, H, lx0, ly0, w, h, present):
    """Bottom-left first fit. present = list of (X0,Y0,X1,Y1) world AABBs to avoid.
    Returns (px, py, X0, Y0, X1, Y1) with px,py integer reference coords, or None."""
    base_x = max(0, math.ceil(-lx0)); base_y = max(0, math.ceil(-ly0))
    xs = {base_x}; ys = {base_y}
    for (a0, b0, a1, b1) in present:
        nx = math.ceil(a1 - lx0)
        if nx >= 0 and nx + lx0 + w <= W + 1e-9:
            xs.add(nx)
        ny = math.ceil(b1 - ly0)
        if ny >= 0 and ny + ly0 + h <= H + 1e-9:
            ys.add(ny)
    xs = sorted(v for v in xs if v + lx0 >= -1e-9 and v + lx0 + w <= W + 1e-9)
    ys = sorted(v for v in ys if v + ly0 >= -1e-9 and v + ly0 + h <= H + 1e-9)
    for py in ys:
        Y0 = py + ly0; Y1 = Y0 + h
        for px in xs:
            X0 = px + lx0; X1 = X0 + w
            ok = True
            for (a0, b0, a1, b1) in present:
                if X0 < a1 - 1e-9 and a0 < X1 - 1e-9 and Y0 < b1 - 1e-9 and b0 < Y1 - 1e-9:
                    ok = False; break
            if ok:
                return px, py, X0, Y0, X1, Y1
    return None


def _pack_bay(P, j, ids, ent_cap=64):
    """Dispatch to the C decoder when available, else the Python reference.
    Both are verified to produce identical placements / tardiness / load."""
    lib = P.get("_lib")
    if lib is not None and P.get("_G") is not None:
        try:
            return _pack_bay_c(P, j, ids, ent_cap)
        except Exception:
            pass
    return _pack_bay_py(P, j, ids, ent_cap)


def _pack_bay_c(P, j, ids, ent_cap=64):
    lib = P["_lib"]; G = P["_G"]
    due = P["due"]; wl = P["wl"]
    place = {}
    nblk = len(ids)
    if nblk == 0:
        return place, 0, 0
    idsa = _np.asarray(ids, _np.int64)
    rel = _np.ascontiguousarray(G["grel"][idsa])
    proc = _np.ascontiguousarray(G["gproc"][idsa])
    ostart = _np.ascontiguousarray(G["gostart"][idsa])
    oend = _np.ascontiguousarray(G["goend"][idsa])
    ox = _np.zeros(nblk, _np.int32); oy = _np.zeros(nblk, _np.int32); ooi = _np.zeros(nblk, _np.int32)
    oe = _np.zeros(nblk, _np.int64); of = _np.zeros(nblk, _np.int64)
    IP = ctypes.POINTER(ctypes.c_int); DP = ctypes.POINTER(ctypes.c_double); LP = ctypes.POINTER(ctypes.c_long)
    ip = lambda a: a.ctypes.data_as(IP)
    dp = lambda a: a.ctypes.data_as(DP)
    lp = lambda a: a.ctypes.data_as(LP)
    rc = lib.decode_bay(float(P["BW"][j]), float(P["BH"][j]), nblk,
                        ip(rel), ip(proc), ip(ostart), ip(oend),
                        ip(G["goidx"]), dp(G["golx"]), dp(G["goly"]), dp(G["gow"]), dp(G["goh"]),
                        int(ent_cap), ip(ox), ip(oy), ip(ooi), lp(oe), lp(of))
    if rc != 0:
        raise RuntimeError("decode_bay rc=%d" % rc)
    tard = 0; load = 0
    for k in range(nblk):
        bid = ids[k]
        e = int(oe[k]); f = int(of[k])
        place[bid] = (int(ox[k]), int(oy[k]), int(ooi[k]), e, f)
        load += wl[bid]
        if f > due[bid]:
            tard += f - due[bid]
    return place, tard, load


def _pack_bay_py(P, j, ids, ent_cap=64):
    """Pack `ids` (in priority order) into bay j. Returns (place, tard, load).
    place[bid] = (x, y, orient_idx, entry, exit)."""
    W = P["BW"][j]; H = P["BH"][j]
    rel = P["rel"]; proc = P["proc"]; due = P["due"]; wl = P["wl"]; orients = P["orients"]
    active = []     # (X0, Y0, X1, Y1, entry, exit)
    place = {}
    tard = 0
    load = 0
    for bid in ids:
        r = rel[bid]; p = proc[bid]
        load += wl[bid]
        cand_t = sorted({r} | {a[5] for a in active if a[5] > r})
        if len(cand_t) > ent_cap:
            cand_t = cand_t[:ent_cap]
        best = None     # (entry, Y1, px, py, oi, X0, Y0, X1, Y1)
        for e in cand_t:
            present = [(a[0], a[1], a[2], a[3]) for a in active if a[5] > e and a[4] < e + p]
            for (oi, lx0, ly0, w, h) in orients[bid]:
                pos = _best_fit(W, H, lx0, ly0, w, h, present)
                if pos is None:
                    continue
                px, py, X0, Y0, X1, Y1 = pos
                cand = (e, Y1, px, py, oi, X0, Y0, X1, Y1)
                if best is None or (cand[0], cand[1]) < (best[0], best[1]):
                    best = cand
            if best is not None and best[0] == e:
                break
        if best is None:
            e = max(r, max((a[5] for a in active), default=0))
            chosen = None
            for (oi, lx0, ly0, w, h) in orients[bid]:
                if _ori_fits_bay(lx0, ly0, w, h, W, H):
                    chosen = (oi, lx0, ly0, w, h); break
            if chosen is None:
                chosen = orients[bid][0]
            oi, lx0, ly0, w, h = chosen
            px = math.ceil(-lx0 - 1e-9); py = math.ceil(-ly0 - 1e-9)
            X0, Y0, X1, Y1 = px + lx0, py + ly0, px + lx0 + w, py + ly0 + h
            best = (e, Y1, px, py, oi, X0, Y0, X1, Y1)
        e, _, px, py, oi, X0, Y0, X1, Y1 = best
        f = e + p
        active.append((X0, Y0, X1, Y1, e, f))
        place[bid] = (px, py, oi, e, f)
        if f > due[bid]:
            tard += f - due[bid]
    return place, tard, load


# ===========================================================================
# Objective (matches utils.check_feasibility exactly: Z2 is floored)
# ===========================================================================

def _objective(P, loads, tard_sum, assign):
    u = P["m"] >= 2
    if u:
        vals = [P["u"][j] * loads[j] for j in range(P["m"])]
        z2 = math.floor(max(vals) - min(vals))
    else:
        z2 = 0.0
    z3 = 0
    smax = P["smax"]; pref = P["pref"]
    for i, j in enumerate(assign):
        z3 += smax[i] - pref[i][j]
    return P["w1"] * tard_sum + P["w2"] * z2 + P["w3"] * z3, z2, z3


# ===========================================================================
# A full solution object operating on the single representation
# ===========================================================================

class Sol:
    """Holds assign + per-bay order, the decode cache, and the live objective."""
    __slots__ = ("P", "assign", "order", "place", "tard", "load", "obj")

    def __init__(self, P, assign, orders=None):
        self.P = P
        self.assign = list(assign)
        m = P["m"]
        if orders is None:
            orders = [[] for _ in range(m)]
            for i, j in enumerate(self.assign):
                orders[j].append(i)
            for j in range(m):
                orders[j] = _edd_order(P, orders[j])
        self.order = [list(o) for o in orders]
        self.place = [None] * m
        self.tard = [0] * m
        self.load = [0] * m
        for j in range(m):
            self._decode_bay(j)
        self.obj = self._recompute_obj()

    def _decode_bay(self, j):
        pl, td, ld = _pack_bay(self.P, j, self.order[j])
        self.place[j] = pl; self.tard[j] = td; self.load[j] = ld

    def _recompute_obj(self):
        obj, _, _ = _objective(self.P, self.load, sum(self.tard), self.assign)
        return obj

    def clone(self):
        s = Sol.__new__(Sol)
        s.P = self.P
        s.assign = list(self.assign)
        s.order = [list(o) for o in self.order]
        s.place = [dict(p) if p is not None else None for p in self.place]
        s.tard = list(self.tard)
        s.load = list(self.load)
        s.obj = self.obj
        return s

    def to_solution(self):
        """Build the competition operations dict from the decode cache."""
        from collections import defaultdict
        by_t = defaultdict(lambda: {"EXIT": [], "ENTRY": []})
        for j in range(self.P["m"]):
            for bid, (x, y, oi, e, f) in self.place[j].items():
                by_t[e]["ENTRY"].append({
                    "type": "ENTRY", "block_id": int(bid), "bay_id": int(j),
                    "x": int(round(x)), "y": int(round(y)), "orient_idx": int(oi)})
                by_t[f]["EXIT"].append({
                    "type": "EXIT", "block_id": int(bid), "bay_id": int(j)})
        ops = {}
        for t in sorted(by_t.keys()):
            day = by_t[t]["EXIT"] + by_t[t]["ENTRY"]   # EXIT before ENTRY
            if day:
                ops[str(int(t))] = day
        return {"operations": ops}


def _edd_order(P, ids):
    due = P["due"]; rel = P["rel"]; proc = P["proc"]
    return sorted(ids, key=lambda i: (due[i], rel[i], proc[i]))


# ===========================================================================
# Construction: a handful of assignment seeds
# ===========================================================================

def _seed_pref(P):
    """Each block to its most-preferred bay it actually fits in (Z3 minimal)."""
    assign = [0] * P["n"]
    for i in range(P["n"]):
        fb = P["fitbays"][i]; pr = P["pref"][i]
        assign[i] = max(fb, key=lambda j: pr[j])
    return assign


def _seed_balanced(P):
    """Greedily balance u_j * load while respecting fit; light preference tilt."""
    m = P["m"]; u = P["u"]; wl = P["wl"]; pref = P["pref"]
    load = [0.0] * m
    order = sorted(range(P["n"]), key=lambda i: -wl[i])
    assign = [0] * P["n"]
    for i in order:
        fb = P["fitbays"][i]
        best_j = min(fb, key=lambda j: (u[j] * (load[j] + wl[i]), -pref[i][j]))
        assign[i] = best_j
        load[best_j] += wl[i]
    return assign


def _seed_capacity(P):
    """Preference-first, but spill to the next-best bay when a bay's rough
    concurrent-area demand would exceed its area (keeps packing spatially sane)."""
    m = P["m"]; pref = P["pref"]; orients = P["orients"]
    cap = [P["areas"][j] for j in range(m)]
    # crude concurrent-area proxy: total footprint area scaled by overlap factor
    rel = P["rel"]; proc = P["proc"]
    horizon = max((rel[i] + proc[i] for i in range(P["n"])), default=1)
    horizon = max(horizon, 1)
    used = [0.0] * m
    assign = [0] * P["n"]
    order = sorted(range(P["n"]), key=lambda i: -(orients[i][0][3] * orients[i][0][4]))
    for i in order:
        fb = P["fitbays"][i]
        a = orients[i][0][3] * orients[i][0][4]
        demand = a * (proc[i] / horizon)     # time-averaged area
        ranked = sorted(fb, key=lambda j: -pref[i][j])
        chosen = ranked[0]
        for j in ranked:
            if used[j] + demand <= cap[j]:
                chosen = j; break
        assign[i] = chosen
        used[chosen] += demand
    return assign


def _seed_cpsat(P, tlimit):
    """Exact-ish assignment minimising w2*Z2 + w3*Z3 (no packing); ortools."""
    try:
        from ortools.sat.python import cp_model
    except Exception:
        return None
    n = P["n"]; m = P["m"]
    if m < 2 or n * m > 6000:
        return None
    model = cp_model.CpModel()
    x = {}
    for i in range(n):
        fb = P["fitbays"][i]
        for j in fb:
            x[i, j] = model.NewBoolVar(f"x_{i}_{j}")
        model.Add(sum(x[i, j] for j in fb) == 1)
    wl = P["wl"]
    load = []
    for j in range(m):
        lj = model.NewIntVar(0, sum(wl) + 1, f"load_{j}")
        model.Add(lj == sum(wl[i] * x[i, j] for i in range(n) if (i, j) in x))
        load.append(lj)
    SC = 1000
    su = [int(round(P["u"][j] * SC)) for j in range(m)]
    val = []
    maxprod = (sum(wl) + 1) * (max(su) + 1)
    for j in range(m):
        vj = model.NewIntVar(0, maxprod, f"val_{j}")
        model.Add(vj == su[j] * load[j])
        val.append(vj)
    hi = model.NewIntVar(0, maxprod, "hi"); lo = model.NewIntVar(0, maxprod, "lo")
    model.AddMaxEquality(hi, val); model.AddMinEquality(lo, val)
    smax = P["smax"]; pref = P["pref"]
    z3_terms = []
    for i in range(n):
        for j in P["fitbays"][i]:
            c = smax[i] - pref[i][j]
            if c:
                z3_terms.append(c * x[i, j])
    w2i = int(round(P["w2"])); w3i = int(round(P["w3"] * SC))
    model.Minimize(w2i * (hi - lo) + w3i * sum(z3_terms))
    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = max(1.0, tlimit)
    solver.parameters.num_search_workers = 4
    st = solver.Solve(model)
    if st not in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        return None
    assign = [0] * n
    for i in range(n):
        for j in P["fitbays"][i]:
            if solver.Value(x[i, j]) == 1:
                assign[i] = j; break
    return assign


# ===========================================================================
# Per-bay order optimisation (Z1 lever, separable, touches one bay)
# ===========================================================================

def _best_order_for_bay(P, j, ids, deadline):
    """Try canonical orders, return (best_order, place, tard, load)."""
    due = P["due"]; rel = P["rel"]; proc = P["proc"]; orients = P["orients"]
    cands = [
        sorted(ids, key=lambda i: (due[i], rel[i])),
        sorted(ids, key=lambda i: (rel[i], due[i])),
        sorted(ids, key=lambda i: -(orients[i][0][3] * orients[i][0][4])),
        sorted(ids, key=lambda i: (due[i] - proc[i], rel[i])),     # slack/critical-ratio-ish
    ]
    best = None
    for od in cands:
        if time.perf_counter() > deadline:
            break
        pl, td, ld = _pack_bay(P, j, od)
        if best is None or td < best[2]:
            best = (od, pl, td, ld)
    return best


def _polish_bay_swaps(P, j, sol, deadline, max_pass=2):
    """Local adjacent/shift improvement of one bay's order to cut tardiness."""
    ids = sol.order[j]
    n = len(ids)
    if n < 3:
        return
    cur_t = sol.tard[j]
    for _ in range(max_pass):
        improved = False
        for a in range(n - 1):
            if time.perf_counter() > deadline:
                return
            b = a + 1
            trial = list(ids)
            trial[a], trial[b] = trial[b], trial[a]
            pl, td, ld = _pack_bay(P, j, trial)
            if td < cur_t:
                ids = trial; cur_t = td
                sol.order[j] = ids; sol.place[j] = pl; sol.tard[j] = td; sol.load[j] = ld
                improved = True
        if not improved:
            break
    sol.obj = sol._recompute_obj()


def _optimise_all_orders(P, sol, deadline):
    # bays ordered by current tardiness (work the worst first)
    js = sorted(range(P["m"]), key=lambda j: -sol.tard[j])
    for j in js:
        if time.perf_counter() > deadline:
            break
        ids = sol.order[j]
        if not ids:
            continue
        res = _best_order_for_bay(P, j, ids, deadline)
        if res is not None:
            od, pl, td, ld = res
            if td <= sol.tard[j]:
                sol.order[j] = od; sol.place[j] = pl; sol.tard[j] = td; sol.load[j] = ld
        _polish_bay_swaps(P, j, sol, deadline)
    sol.obj = sol._recompute_obj()


def _order_lns(P, sol, deadline, rng):
    """Randomized ruin-and-recreate on per-bay order to use leftover budget.
    Assignment is fixed, so only Z1 can change and only improvements are kept
    (with rare equal-tardiness moves for plateau exploration)."""
    m = P["m"]
    cand = [j for j in range(m) if len(sol.order[j]) >= 3]
    if not cand:
        return
    due = P["due"]
    stall = 0
    kick_at = 250
    while time.perf_counter() < deadline:
        if sum(sol.tard) <= 0:
            return  # reordering cannot reduce Z1 below zero
        live = [j for j in cand if sol.tard[j] > 0] or cand
        weights = [sol.tard[j] + 1 for j in live]
        j = rng.choices(live, weights=weights)[0]
        ids = sol.order[j]; n = len(ids); cur = sol.tard[j]
        trial = list(ids)
        if stall >= kick_at:
            # escalated kick: ruin a chunk and reinsert it by EDD
            klen = max(2, min(n, int(n * (0.15 + 0.25 * rng.random()))))
            start = rng.randrange(max(1, n - klen + 1))
            chunk = trial[start:start + klen]
            del trial[start:start + klen]
            chunk.sort(key=lambda i: (due[i], P["rel"][i]))
            ins = rng.randrange(len(trial) + 1)
            trial[ins:ins] = chunk
            stall = 0
        elif rng.random() < 0.5:
            a = rng.randrange(n); b = rng.randrange(n)
            if a > b:
                a, b = b, a
            trial[a:b + 1] = reversed(trial[a:b + 1])
        else:
            a = rng.randrange(n); blk = trial.pop(a)
            b = rng.randrange(len(trial) + 1); trial.insert(b, blk)
        pl, td, ld = _pack_bay(P, j, trial)
        if td < cur:
            sol.obj += P["w1"] * (td - cur)
            sol.order[j] = trial; sol.place[j] = pl; sol.tard[j] = td; sol.load[j] = ld
            stall = 0
        elif td == cur and rng.random() < 0.20:
            sol.order[j] = trial; sol.place[j] = pl; sol.tard[j] = td; sol.load[j] = ld
            stall += 1
        else:
            stall += 1


# ===========================================================================
# Cross-bay simulated annealing (trades Z1 / Z2 / Z3 on the true objective)
# ===========================================================================

def _sa(P, sol, deadline, rng):
    n = P["n"]; m = P["m"]
    if m < 2 or n == 0:
        return sol
    best = sol.clone()
    cur = sol

    # adaptive temperature: sample a few move magnitudes
    samples = []
    for _ in range(min(24, 4 * n)):
        i = rng.randrange(n)
        fb = P["fitbays"][i]
        if len(fb) < 2:
            continue
        j0 = cur.assign[i]
        j1 = rng.choice([j for j in fb if j != j0])
        d = _try_move(P, cur, i, j1, accept=False)
        if d is not None:
            samples.append(abs(d))
    T0 = (sorted(samples)[len(samples) // 2] if samples else max(1.0, abs(cur.obj) * 1e-3))
    T0 = max(T0, 1.0)
    Tend = max(T0 * 1e-3, 1e-6)

    t_start = time.perf_counter()
    total = max(deadline - t_start, 1e-6)
    it = 0
    while True:
        now = time.perf_counter()
        if now > deadline:
            break
        frac = (now - t_start) / total
        T = T0 * ((Tend / T0) ** frac)
        it += 1

        # choose a block, prefer tardy ones
        if rng.random() < 0.7:
            i = _pick_tardy_block(P, cur, rng)
        else:
            i = rng.randrange(n)
        fb = P["fitbays"][i]
        if len(fb) < 2:
            continue
        j0 = cur.assign[i]
        j1 = rng.choice([j for j in fb if j != j0])
        d = _try_move(P, cur, i, j1, accept=False)
        if d is None:
            continue
        if d <= 0 or rng.random() < math.exp(-d / T):
            _try_move(P, cur, i, j1, accept=True)
            if cur.obj < best.obj - 1e-9:
                best = cur.clone()
    return best


def _pick_tardy_block(P, sol, rng):
    # weight by tardiness of the bay each block is in; fall back to uniform
    due = P["due"]
    tardy = [i for j in range(P["m"]) for i in sol.order[j]
             if sol.place[j].get(i, (0, 0, 0, 0, 0))[4] > due[i]]
    if tardy:
        return rng.choice(tardy)
    return rng.randrange(P["n"])


def _try_move(P, sol, i, j1, accept):
    """Move block i to bay j1. If accept=False, returns obj delta without
    committing (state restored). If accept=True, commits and returns delta."""
    j0 = sol.assign[i]
    if j0 == j1:
        return 0.0
    # snapshot the two bays
    o0, o1 = sol.order[j0], sol.order[j1]
    save = (list(o0), list(o1), dict(sol.place[j0]), dict(sol.place[j1]),
            sol.tard[j0], sol.tard[j1], sol.load[j0], sol.load[j1], sol.obj, sol.assign[i])
    new0 = [b for b in o0 if b != i]
    new1 = _insert_edd(P, list(o1), i)
    pl0, td0, ld0 = _pack_bay(P, j0, new0)
    pl1, td1, ld1 = _pack_bay(P, j1, new1)
    old_tard = sum(sol.tard)
    new_tard = old_tard - sol.tard[j0] - sol.tard[j1] + td0 + td1
    new_load = list(sol.load); new_load[j0] = ld0; new_load[j1] = ld1
    sol.assign[i] = j1
    new_obj, _, _ = _objective(P, new_load, new_tard, sol.assign)
    delta = new_obj - save[8]
    if accept:
        sol.order[j0] = new0; sol.order[j1] = new1
        sol.place[j0] = pl0; sol.place[j1] = pl1
        sol.tard[j0] = td0; sol.tard[j1] = td1
        sol.load[j0] = ld0; sol.load[j1] = ld1
        sol.obj = new_obj
        return delta
    # restore
    sol.order[j0], sol.order[j1] = save[0], save[1]
    sol.place[j0], sol.place[j1] = save[2], save[3]
    sol.tard[j0], sol.tard[j1] = save[4], save[5]
    sol.load[j0], sol.load[j1] = save[6], save[7]
    sol.obj = save[8]; sol.assign[i] = save[9]
    return delta


def _insert_edd(P, ids, i):
    due = P["due"]
    pos = len(ids)
    for k, b in enumerate(ids):
        if due[i] < due[b]:
            pos = k; break
    ids.insert(pos, i)
    return ids


# ===========================================================================
# Assignment large-neighbourhood search (ruin-and-recreate)
# ===========================================================================
# Single-move SA freezes once Z1 hits 0: with w1 huge, moving any one block to
# its preferred bay congests that bay (Z1>0, +w1 penalty) and is rejected, so
# the preference penalty Z3 cannot fall further.  ALNS removes a batch of
# poorly-placed blocks at once and reinserts them by marginal true-objective
# cost, which CO-ORDINATES the reassignment and reaches the low-Z3 / packable
# assignments that single moves cannot.

def _z2_of(P, load):
    if P["m"] < 2:
        return 0.0
    u = P["u"]
    vals = [u[j] * load[j] for j in range(P["m"])]
    return math.floor(max(vals) - min(vals))


def _marginal_insert(P, sol, bid, j, z2_base_load):
    """Cost of inserting bid into bay j (EDD position) via a bay re-decode."""
    order = _insert_edd(P, list(sol.order[j]), bid)
    pl, td, ld = _pack_bay(P, j, order)
    nl = list(z2_base_load); nl[j] = ld
    dz1 = P["w1"] * (td - sol.tard[j])
    dz2 = P["w2"] * (_z2_of(P, nl) - _z2_of(P, z2_base_load))
    dz3 = P["w3"] * (P["smax"][bid] - P["pref"][bid][j])
    return dz1 + dz2 + dz3, order, pl, td, ld


def _ruin_recreate(P, s, ruin, rng):
    """In-place ruin of `ruin` blocks then greedy marginal recreate of s."""
    smax = P["smax"]; pref = P["pref"]; fitbays = P["fitbays"]
    ruin = list(dict.fromkeys(ruin))   # dedupe: never remove/insert a block twice
    touched = set()
    for bid in ruin:
        j = s.assign[bid]
        s.order[j] = [b for b in s.order[j] if b != bid]
        touched.add(j)
    for j in touched:
        pl, td, ld = _pack_bay(P, j, s.order[j])
        s.place[j] = pl; s.tard[j] = td; s.load[j] = ld
    for bid in sorted(ruin, key=lambda b: -(smax[b] - min(pref[b][k] for k in fitbays[b]))):
        base_load = s.load
        bestc = None
        for j in fitbays[bid]:
            d, order, pl, td, ld = _marginal_insert(P, s, bid, j, base_load)
            if bestc is None or d < bestc[0]:
                bestc = (d, j, order, pl, td, ld)
        _, j, order, pl, td, ld = bestc
        s.assign[bid] = j; s.order[j] = order
        s.place[j] = pl; s.tard[j] = td; s.load[j] = ld
    s.obj = s._recompute_obj()


def _ruin_set(P, s, rng, kfrac, biased):
    n = P["n"]
    K = max(2, min(n, int(round(n * kfrac))))
    if biased:
        due = P["due"]
        # blocks that are themselves tardy (these directly drive Z1, which
        # dominates when w1 is large) plus blocks sitting off their preferred bay
        tardy = [bid for j in range(P["m"]) for bid, pl in s.place[j].items()
                 if pl[4] > due[bid]]
        offpref = [i for i in range(n) if P["smax"][i] - P["pref"][i][s.assign[i]] > 0]
        pool = list(set(tardy) | set(offpref))   # dedupe: sample must not repeat a block
        if pool and rng.random() < 0.85:
            if len(pool) >= K:
                return rng.sample(pool, K)
            extra = [b for b in rng.sample(range(n), min(n, K + len(pool))) if b not in pool]
            return pool + extra[: max(0, K - len(pool))]
    return rng.sample(range(n), K)


def _local_descent(P, s, rng, deadline, max_stall=10, kfrac=0.10):
    """Greedy ruin-and-recreate, accepting only improvements, until `max_stall`
    consecutive non-improving moves or the deadline."""
    stall = 0
    while stall < max_stall and time.perf_counter() < deadline:
        trial = s.clone()
        _ruin_recreate(P, trial, _ruin_set(P, trial, rng, kfrac, True), rng)
        if trial.obj < s.obj - 1e-9:
            s = trial; stall = 0
        else:
            stall += 1
    return s


def _alns(P, sol, deadline, rng, kfrac=0.15, stall=55):
    """Multi-restart ruin-and-recreate over the assignment.  A single greedy
    descent is high variance (it gets trapped in different basins), so we run
    repeated independent descents from diversified starts and keep the global
    best.  With a realistic (minutes) budget this reliably reaches the good
    basin rather than gambling on one trajectory."""
    n = P["n"]; m = P["m"]
    if m < 2 or n < 4:
        return sol
    smax = P["smax"]; pref = P["pref"]; fitbays = P["fitbays"]
    best_global = sol.clone()
    # diversified restart starting points
    bases = [sol]
    try:
        bases.append(Sol(P, _seed_pref(P)))
    except Exception:
        pass
    try:
        bases.append(Sol(P, _seed_balanced(P)))
    except Exception:
        pass
    try:
        bases.append(Sol(P, _seed_capacity(P)))
    except Exception:
        pass
    ri = 0
    while time.perf_counter() < deadline:
        # pick a start: cycle bases, then random assignments for further diversity
        if ri < len(bases):
            local = bases[ri].clone()
        else:
            a = [rng.choice(fitbays[i]) for i in range(n)]
            local = Sol(P, a)
        ri += 1
        local_stall = 0
        while local_stall < stall and time.perf_counter() < deadline:
            trial = local.clone()
            kf = kfrac * (0.5 + rng.random())
            ruin = _ruin_set(P, trial, rng, kf, True)
            _ruin_recreate(P, trial, ruin, rng)
            if trial.obj < local.obj - 1e-9:
                local = trial; local_stall = 0
            else:
                local_stall += 1
        if local.obj < best_global.obj - 1e-9:
            best_global = local
    return best_global


# ===========================================================================
# Optional CP-SAT per-bay packing polish (small bays only -- no huge-bay trap)
# ===========================================================================
# Kept intentionally OUT of the hot path; the geometric decoder is the packer.
# A small-bay exact densifier can be added here later if profiling shows the
# decoder leaving tardiness on the table for genuinely small bays.


# ===========================================================================
# Entry point
# ===========================================================================

def quick_solution(prob_info, timelimit=60):
    t0 = time.perf_counter()
    # leave generous headroom for the self-check + emit (esp. on large instances)
    compute_deadline = t0 + timelimit * 0.85
    rng = random.Random(12345)

    P = _prep(prob_info)

    # Always-feasible baseline, computed up front and instantly: if anything
    # below is too slow or misbehaves on this instance, we still return this.
    try:
        serial = _serial_solution(P)
    except Exception:
        serial = {"operations": {}}

    # Safety valve: without the C decoder a very large bay would make the pure-
    # Python packer too slow to finish within the limit -> return the serial
    # floor rather than risk a timeout (= -1).
    if P.get("_lib") is None and P["n"] > 800:
        return serial

    # ---- construct seeds ---------------------------------------------------
    seeds = []
    try:
        seeds.append(_seed_pref(P))
    except Exception:
        pass
    try:
        seeds.append(_seed_balanced(P))
    except Exception:
        pass
    try:
        seeds.append(_seed_capacity(P))
    except Exception:
        pass
    # CP-SAT assignment seed, time-boxed and size-gated
    cpsat_assign = None
    cp_budget = min(8.0, timelimit * 0.15)
    if time.perf_counter() + cp_budget < compute_deadline:
        try:
            a = _seed_cpsat(P, cp_budget)
            if a is not None:
                cpsat_assign = a
                seeds.append(a)
        except Exception:
            pass

    best = None
    for a in seeds:
        if time.perf_counter() > compute_deadline:
            break
        try:
            s = Sol(P, a)
            if best is None or s.obj < best.obj:
                best = s
        except Exception:
            continue

    if best is None:
        # absolute fallback: everyone to their first fitting bay, EDD order
        a = [P["fitbays"][i][0] for i in range(P["n"])]
        best = Sol(P, a)

    # ---- improve: single abstraction, anytime ------------------------------
    # Exact-assignment candidate first (assignment-dominated instances): the
    # CP-SAT Z2/Z3-optimal assignment, order-packed toward Z1=0.  Monotone.
    if cpsat_assign is not None and P["m"] >= 2 and time.perf_counter() < compute_deadline:
        try:
            cand = Sol(P, cpsat_assign)
            pdl = min(compute_deadline, t0 + timelimit * 0.18)
            _optimise_all_orders(P, cand, pdl)
            _order_lns(P, cand, pdl, rng)
            if cand.obj < best.obj:
                best = cand
        except Exception:
            pass

    # Brief per-bay ordering on the incumbent.
    _optimise_all_orders(P, best, min(compute_deadline, t0 + timelimit * 0.25))

    # MAIN ENGINE: assignment ruin-and-recreate.  This is what reaches the
    # low-Z3 / packable assignments that single-move search cannot.  (For
    # single-bay instances it is a no-op and the whole budget flows to the
    # order search in the tail below.)  We stop it before the deadline so the
    # tail order search gets real budget -- on Z1-dominated instances squeezing
    # the last tardiness units off the best assignment is worth more than more
    # assignment churn (each tardiness unit costs w1, which is large).
    if P["m"] >= 2:
        best = _alns(P, best, min(compute_deadline, t0 + timelimit * 0.70), rng)

    # Guaranteed tail: order polish + randomized order LNS (Z1 only, monotone).
    _optimise_all_orders(P, best, min(compute_deadline, t0 + timelimit * 0.80))
    if time.perf_counter() < compute_deadline:
        _order_lns(P, best, compute_deadline, rng)

    # ---- emit + verify -----------------------------------------------------
    # Fast structural self-check (validator-aligned geometry + duplicate guard);
    # fall back to the always-feasible serial floor if it fails.
    try:
        ok = _solution_self_feasible(P, best)
    except Exception:
        ok = False
    solution = best.to_solution() if ok else serial

    # Strongest net for SMALL-BAY instances: confirm with the real validator
    # when there is time.  We deliberately exclude large-bay instances (where
    # many blocks coexist and the validator's pairwise checks get slow) so this
    # can never reintroduce a validator-call timeout on a P3-style instance --
    # those rely on the fast self-check (which also catches duplicates) + serial.
    max_area = max(P["BW"][j] * P["BH"][j] for j in range(P["m"])) if P["m"] else 0
    if P["n"] <= 500 and max_area <= 15000 and time.perf_counter() < t0 + timelimit * 0.94:
        try:
            import utils as _u
            if not _u.check_feasibility(prob_info, solution).get("feasible", False):
                cand = serial
                if _u.check_feasibility(prob_info, cand).get("feasible", False):
                    solution = cand
        except Exception:
            pass
    return solution


def _serial_solution(P):
    """One block at a time per bay -- always-feasible insurance net.  Each block
    is placed in an orientation that actually fits its bay (integer placement),
    at the lower-left feasible reference, single-occupancy so nothing overlaps."""
    from collections import defaultdict
    by_t = defaultdict(lambda: {"EXIT": [], "ENTRY": []})
    assign = [max(P["fitbays"][i], key=lambda j: P["pref"][i][j]) for i in range(P["n"])]
    rel = P["rel"]; proc = P["proc"]; orients = P["orients"]; BW = P["BW"]; BH = P["BH"]
    by_bay = defaultdict(list)
    for i in range(P["n"]):
        by_bay[assign[i]].append(i)
    for j, ids in by_bay.items():
        ids.sort(key=lambda i: (P["due"][i], rel[i]))
        t = 0
        for bid in ids:
            e = max(rel[bid], t)
            f = e + proc[bid]
            chosen = None
            for cand in orients[bid]:
                if _ori_fits_bay(cand[1], cand[2], cand[3], cand[4], BW[j], BH[j]):
                    chosen = cand; break
            if chosen is None:
                chosen = orients[bid][0]
            oi, lx0, ly0, w, h = chosen
            x = math.ceil(-lx0 - 1e-9); y = math.ceil(-ly0 - 1e-9)
            by_t[e]["ENTRY"].append({"type": "ENTRY", "block_id": int(bid), "bay_id": int(j),
                                     "x": int(x), "y": int(y), "orient_idx": int(oi)})
            by_t[f]["EXIT"].append({"type": "EXIT", "block_id": int(bid), "bay_id": int(j)})
            t = f
    ops = {}
    for tt in sorted(by_t.keys()):
        day = by_t[tt]["EXIT"] + by_t[tt]["ENTRY"]
        if day:
            ops[str(int(tt))] = day
    return {"operations": ops}


def _geom(P, bid, oi):
    for cand in P["orients"][bid]:
        if cand[0] == oi:
            return cand[1], cand[2], cand[3], cand[4]
    c = P["orients"][bid][0]
    return c[1], c[2], c[3], c[4]


def _solution_self_feasible(P, sol, tol=1e-6):
    """Fast structural feasibility self-check using the SAME geometry the
    validator uses (matched in _prep): every block's footprint AABB inside its
    bay, and time-overlapping blocks footprint-disjoint (=> no layer collision
    and crane-feasible, by the keystone fact).  Catches gross geometry errors
    such as a mis-set reference point.  Per-bay pairwise check is skipped for
    very large bays (the decoder already guarantees disjointness there)."""
    BW = P["BW"]; BH = P["BH"]
    seen_blocks = set()
    for j in range(P["m"]):
        place = sol.place[j]
        if not place:
            continue
        for bid in place:
            if bid in seen_blocks:   # a block scheduled in two bays => infeasible
                return False
            seen_blocks.add(bid)
        W = BW[j]; H = BH[j]
        items = []
        for bid, (x, y, oi, e, f) in place.items():
            lx0, ly0, w, h = _geom(P, bid, oi)
            X0 = x + lx0; Y0 = y + ly0; X1 = X0 + w; Y1 = Y0 + h
            if X0 < -tol or Y0 < -tol or X1 > W + tol or Y1 > H + tol:
                return False
            items.append((e, f, X0, Y0, X1, Y1))
        nI = len(items)
        if nI > 2000:
            continue
        items.sort(key=lambda it: it[0])
        for a in range(nI):
            e1, f1, A0, B0, A1, B1 = items[a]
            for b in range(a + 1, nI):
                e2, f2, C0, D0, C1, D1 = items[b]
                if e2 >= f1:
                    break  # sorted by entry; no later block overlaps in time
                if e1 < f2 and A0 < C1 - tol and C0 < A1 - tol and B0 < D1 - tol and D0 < B1 - tol:
                    return False
    return True
