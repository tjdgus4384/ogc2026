/* geomdecode.c -- fast footprint-disjoint per-bay decoder.
 * Identical semantics to the Python reference _pack_bay/_best_fit.
 * Orientation data is global/static; each call passes per-block [ostart,oend)
 * ranges into the global arrays, so re-decoding a bay needs no payload rebuild.
 * Build: gcc -O3 -shared -fPIC -o geomdecode.so geomdecode.c
 */
#include <stdlib.h>
#include <math.h>
#define EPS 1e-9

static int ceil_i(double v){ return (int)ceil(v - 1e-12); }
static int cmp_int(const void *a,const void *b){
    int x=*(const int*)a,y=*(const int*)b; return (x>y)-(x<y);
}

static int best_fit(double W,double H,double lx0,double ly0,double w,double h,
                    int np,const double*pX0,const double*pY0,const double*pX1,const double*pY1,
                    int*xs_buf,int*ys_buf,
                    int*opx,int*opy,double*oX0,double*oY0,double*oX1,double*oY1){
    int base_x=ceil_i(-lx0); if(base_x<0)base_x=0;
    int base_y=ceil_i(-ly0); if(base_y<0)base_y=0;
    int nxc=0,nyc=0; xs_buf[nxc++]=base_x; ys_buf[nyc++]=base_y;
    for(int k=0;k<np;++k){
        int nx=ceil_i(pX1[k]-lx0);
        if(nx>=0 && nx+lx0+w<=W+EPS) xs_buf[nxc++]=nx;
        int ny=ceil_i(pY1[k]-ly0);
        if(ny>=0 && ny+ly0+h<=H+EPS) ys_buf[nyc++]=ny;
    }
    qsort(xs_buf,nxc,sizeof(int),cmp_int);
    qsort(ys_buf,nyc,sizeof(int),cmp_int);
    int nxs=0;
    for(int i=0;i<nxc;++i){
        if(i>0 && xs_buf[i]==xs_buf[i-1]) continue;
        double X0=xs_buf[i]+lx0; if(X0>=-EPS && X0+w<=W+EPS) xs_buf[nxs++]=xs_buf[i];
    }
    int nys=0;
    for(int i=0;i<nyc;++i){
        if(i>0 && ys_buf[i]==ys_buf[i-1]) continue;
        double Y0=ys_buf[i]+ly0; if(Y0>=-EPS && Y0+h<=H+EPS) ys_buf[nys++]=ys_buf[i];
    }
    for(int iy=0;iy<nys;++iy){
        double Y0=ys_buf[iy]+ly0,Y1=Y0+h;
        for(int ix=0;ix<nxs;++ix){
            double X0=xs_buf[ix]+lx0,X1=X0+w; int ok=1;
            for(int k=0;k<np;++k){
                if(X0<pX1[k]-EPS && pX0[k]<X1-EPS && Y0<pY1[k]-EPS && pY0[k]<Y1-EPS){ok=0;break;}
            }
            if(ok){*opx=xs_buf[ix];*opy=ys_buf[iy];*oX0=X0;*oY0=Y0;*oX1=X1;*oY1=Y1;return 1;}
        }
    }
    return 0;
}

int decode_bay(double W,double H,int nblk,
               const int*rel,const int*proc,
               const int*ostart,const int*oend,
               const int*goidx,const double*golx,const double*goly,
               const double*gow,const double*goh,
               int ent_cap,
               int*out_x,int*out_y,int*out_oi,long*out_entry,long*out_exit){
    if(nblk<=0) return 0;
    double*aX0=malloc(sizeof(double)*nblk),*aY0=malloc(sizeof(double)*nblk);
    double*aX1=malloc(sizeof(double)*nblk),*aY1=malloc(sizeof(double)*nblk);
    long*aE=malloc(sizeof(long)*nblk),*aF=malloc(sizeof(long)*nblk);
    double*pX0=malloc(sizeof(double)*(nblk+1)),*pY0=malloc(sizeof(double)*(nblk+1));
    double*pX1=malloc(sizeof(double)*(nblk+1)),*pY1=malloc(sizeof(double)*(nblk+1));
    int*cand_t=malloc(sizeof(int)*(nblk+1));
    int*xs_buf=malloc(sizeof(int)*(nblk+2)),*ys_buf=malloc(sizeof(int)*(nblk+2));
    if(!aX0||!aY0||!aX1||!aY1||!aE||!aF||!pX0||!pY0||!pX1||!pY1||!cand_t||!xs_buf||!ys_buf){
        free(aX0);free(aY0);free(aX1);free(aY1);free(aE);free(aF);
        free(pX0);free(pY0);free(pX1);free(pY1);free(cand_t);free(xs_buf);free(ys_buf);
        return -1;
    }
    int nact=0;
    for(int b=0;b<nblk;++b){
        int r=rel[b],p=proc[b];
        int nc=0; cand_t[nc++]=r;
        for(int a=0;a<nact;++a) if(aF[a]>r) cand_t[nc++]=(int)aF[a];
        qsort(cand_t,nc,sizeof(int),cmp_int);
        int uc=0;
        for(int i=0;i<nc;++i){ if(i>0&&cand_t[i]==cand_t[i-1])continue; cand_t[uc++]=cand_t[i]; }
        if(uc>ent_cap) uc=ent_cap;
        int found=0; long best_e=0; int best_x=0,best_y=0,best_oi=0;
        double best_Y1=0,bX0=0,bY0=0,bX1=0,bY1=0;
        for(int ci=0;ci<uc;++ci){
            int e=cand_t[ci];
            int np=0;
            for(int a=0;a<nact;++a) if(aF[a]>e && aE[a]<e+p){
                pX0[np]=aX0[a];pY0[np]=aY0[a];pX1[np]=aX1[a];pY1[np]=aY1[a];np++;
            }
            int e_has=0; double e_bY1=0; int e_x=0,e_y=0,e_oi=0;
            double eX0=0,eY0=0,eX1=0,eY1=0;
            for(int oo=ostart[b];oo<oend[b];++oo){
                int px,py; double X0,Y0,X1,Y1;
                if(best_fit(W,H,golx[oo],goly[oo],gow[oo],goh[oo],np,
                            pX0,pY0,pX1,pY1,xs_buf,ys_buf,&px,&py,&X0,&Y0,&X1,&Y1)){
                    if(!e_has || Y1<e_bY1){ e_has=1;e_bY1=Y1;e_x=px;e_y=py;e_oi=goidx[oo];
                        eX0=X0;eY0=Y0;eX1=X1;eY1=Y1; }
                }
            }
            if(e_has){
                if(!found || (long)e<best_e || ((long)e==best_e && e_bY1<best_Y1)){
                    found=1;best_e=e;best_Y1=e_bY1;best_x=e_x;best_y=e_y;best_oi=e_oi;
                    bX0=eX0;bY0=eY0;bX1=eX1;bY1=eY1;
                }
                break;
            }
        }
        if(!found){
            long e=r; for(int a=0;a<nact;++a) if(aF[a]>e) e=aF[a];
            int chosen=ostart[b],picked=0;
            for(int oo=ostart[b];oo<oend[b];++oo){
                double lx=golx[oo],ly=goly[oo],ww=gow[oo],hh=goh[oo];
                long pxl=(long)ceil(-lx-1e-9), pxh=(long)floor(W-ww-lx+1e-9);
                long pyl=(long)ceil(-ly-1e-9), pyh=(long)floor(H-hh-ly+1e-9);
                if(pxl<=pxh && pyl<=pyh){chosen=oo;picked=1;break;}
            }
            if(!picked) chosen=ostart[b];
            double lx0=golx[chosen],ly0=goly[chosen],w=gow[chosen],h=goh[chosen];
            int px=ceil_i(-lx0); if(px<0)px=0; int py=ceil_i(-ly0); if(py<0)py=0;
            best_e=e;best_x=px;best_y=py;best_oi=goidx[chosen];
            bX0=px+lx0;bY0=py+ly0;bX1=bX0+w;bY1=bY0+h;
        }
        long f=best_e+p;
        aX0[nact]=bX0;aY0[nact]=bY0;aX1[nact]=bX1;aY1[nact]=bY1;aE[nact]=best_e;aF[nact]=f;nact++;
        out_x[b]=best_x;out_y[b]=best_y;out_oi[b]=best_oi;out_entry[b]=best_e;out_exit[b]=f;
    }
    free(aX0);free(aY0);free(aX1);free(aY1);free(aE);free(aF);
    free(pX0);free(pY0);free(pX1);free(pY1);free(cand_t);free(xs_buf);free(ys_buf);
    return 0;
}
